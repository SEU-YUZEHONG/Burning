-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 2019-09-11 23:29:52
-- 服务器版本： 5.7.27-0ubuntu0.18.04.1-log
-- PHP Version: 7.2.19-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basicdb`
--

-- --------------------------------------------------------

--
-- 表的结构 `213173625Job`
--

CREATE TABLE `213173625Job` (
  `jobName` varchar(255) DEFAULT NULL,
  `jobSetDuration` int(11) DEFAULT NULL,
  `jobCreateTime` varchar(255) DEFAULT NULL,
  `jobStartTime` varchar(255) DEFAULT NULL,
  `jobEndTime` varchar(255) DEFAULT NULL,
  `jobType` int(11) DEFAULT NULL,
  `jobScene` varchar(255) DEFAULT NULL,
  `jobAlreadyTime` double DEFAULT NULL,
  `concentration` int(11) DEFAULT NULL,
  `circularity` int(11) DEFAULT NULL,
  `jobSusbendTime` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `213173625Job`
--

INSERT INTO `213173625Job` (`jobName`, `jobSetDuration`, `jobCreateTime`, `jobStartTime`, `jobEndTime`, `jobType`, `jobScene`, `jobAlreadyTime`, `concentration`, `circularity`, `jobSusbendTime`) VALUES
('看书', 3, '60', '2019-09-04 10:22:20:203', '2019-09-05 12:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-05 11:22:20:203', '2019-09-05 12:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-05 11:22:20:203', '2019-09-06 13:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-06 12:22:20:203', '2019-09-06 13:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-07 12:22:20:203', '2019-09-08 13:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-09 11:22:20:203', '2019-09-09 13:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-10 13:22:20:203', '2019-09-10 13:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-09 11:22:20:203', '2019-09-09 13:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('看书', 3, '60', '2019-09-09 08:22:20:203', '2019-09-10 12:25:20:203', 1, '图书馆', 3.06, 21, 2, 1998),
('宽度', 1, '2019-09-11', '2019-09-11 12:22:57:841', '2019-09-11 12:23:58:255', 1, '无', 0, 50, 66, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
