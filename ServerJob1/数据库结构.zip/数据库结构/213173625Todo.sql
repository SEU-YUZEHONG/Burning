-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 2019-09-11 23:31:51
-- 服务器版本： 5.7.27-0ubuntu0.18.04.1-log
-- PHP Version: 7.2.19-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basicdb`
--

-- --------------------------------------------------------

--
-- 表的结构 `213173625Todo`
--

CREATE TABLE `213173625Todo` (
  `jobName` varchar(255) DEFAULT NULL,
  `jobSetDuration` int(11) DEFAULT NULL,
  `jobCreateTime` varchar(255) DEFAULT NULL,
  `jobStartTime` varchar(255) DEFAULT NULL,
  `jobEndTime` varchar(255) DEFAULT NULL,
  `jobType` int(11) DEFAULT NULL,
  `jobScene` varchar(255) DEFAULT NULL,
  `jobAlreadyTime` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `213173625Todo`
--

INSERT INTO `213173625Todo` (`jobName`, `jobSetDuration`, `jobCreateTime`, `jobStartTime`, `jobEndTime`, `jobType`, `jobScene`, `jobAlreadyTime`) VALUES
('看书', 1, '2019-09-11', '2019-09-11', '2019-09-11', 1, '无', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
